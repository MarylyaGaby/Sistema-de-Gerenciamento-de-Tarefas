import {mostrarMenu} from './auxiliar_function.js'

mostrarMenu()

